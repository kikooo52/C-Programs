﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RefactorCode
{
   public class Potato : Vegetable
    {
       public Potato(int quantity)
           : base(quantity)
       {
       }
    }
}
