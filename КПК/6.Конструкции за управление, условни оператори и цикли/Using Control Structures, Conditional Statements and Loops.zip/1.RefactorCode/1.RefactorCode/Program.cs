﻿using System;
using System.Linq;

namespace RefactorCode
{
    class Program
    {
        static void Main(string[] args)
        {
            Chef bashMaistora = new Chef();
            bashMaistora.Cook();
        }
    }
}
