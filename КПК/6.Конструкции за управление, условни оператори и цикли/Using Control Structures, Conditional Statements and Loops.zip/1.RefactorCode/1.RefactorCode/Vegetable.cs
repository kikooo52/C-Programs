﻿using System;
using System.Linq;

namespace RefactorCode
{
  public class Vegetable
    {
      public int Quantity {get; set;}

      public Vegetable(int quantity)
        {
            this.Quantity = quantity;
        }
    }
}
