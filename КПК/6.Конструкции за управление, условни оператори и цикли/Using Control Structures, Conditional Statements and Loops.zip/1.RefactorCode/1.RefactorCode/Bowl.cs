﻿using System;
using System.Linq;
using System.Collections.Generic;

namespace RefactorCode
{
  public class Bowl : List<Vegetable>
    {
    }
}
