﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RefactorCode
{
    class Potato
    {
        public bool IsPeeled { get; set; }
        public bool IsRotten { get; set; }
    }
}
