﻿class Matrix
{
    static void Main()
    {
        RotatingWalkInMatrix.GenerateRotationgMatrix(7);
    }
}

