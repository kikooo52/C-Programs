﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Poker;
using System.Collections.Generic;

namespace PokerTests
{
    [TestClass]
    public class PokerHasdandsCheckerTests
    {
        [TestMethod]
        public void TestToStringAceSpades()
        {
            Hand hand = new Hand(new List<ICard>{
              new Card(CardFace.Two, CardSuit.Clubs),
              new Card(CardFace.Three, CardSuit.Diamonds),
              new Card(CardFace.Four, CardSuit.Hearts),
              new Card(CardFace.Ace, CardSuit.Spades),
              new Card(CardFace.King, CardSuit.Clubs),

          });
            string expected = "2♣3♦4♥A♠K♣";
            string result = hand.ToString();
            Assert.AreEqual(expected, result);

        }
    }
}
